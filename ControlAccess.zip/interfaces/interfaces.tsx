export interface Select {
  value: string;
  label: string;
  tipo: string | undefined;
}