# GoaliePass APP

Aplicativo móvil para Sistema de Control de Acceso GoaliePass.

## Configuración Inicial

Para la instalación de los módulos pertenecientes al proyecto, debe ejecutar:

```bash
npm install
```

## Ejecución del proyecto

Para ejecutar el proyecto, debe ejecutar:

```bash
ionic serve
```

## Generar Transcripcion

```bash
npm run build
```

## Generar Transcripcion

```bash
npx cap add android
npx cap sync android
```